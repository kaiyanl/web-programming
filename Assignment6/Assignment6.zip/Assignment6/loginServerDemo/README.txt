npm install

Run LoginServerDemo
1. node loginServer.js
2. http://server162.site:53119/login.html
