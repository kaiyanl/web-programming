A Pen created at CodePen.io. You can find this one at https://codepen.io/alexdevero/pen/pRjNmW.

 Pen for Learn How to Create Quick and Simple React Flipping Card tutorial on http://blog.alexdevero.com/