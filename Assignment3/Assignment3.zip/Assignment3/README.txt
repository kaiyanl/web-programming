Note:
Function to check distance

From:
https://stackoverflow.com/questions/18883601/function-to-calculate-distance-between-two-coordinates

We used this to convert coordinates to miles using only the object (target city) as we can keep Sacramento's lat/lon constant.
